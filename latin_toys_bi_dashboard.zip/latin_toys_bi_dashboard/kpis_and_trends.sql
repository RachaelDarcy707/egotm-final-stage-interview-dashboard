-- 02_kpis_and_trends.sql
-- Database: OperationsDb
-- Purpose: queries used to calculate key business metrics

USE OperationsDb;

-- Trend in website sessions and order volume (monthly)
SELECT
    YEAR(ws.created_at) AS [year],
    MONTH(ws.created_at) AS [month],
    COUNT(DISTINCT ws.website_session_id) AS sessions,
    COUNT(DISTINCT o.order_id) AS orders
FROM dbo.website_sessions ws
LEFT JOIN dbo.orders o
    ON o.website_session_id = ws.website_session_id
GROUP BY YEAR(ws.created_at), MONTH(ws.created_at)
ORDER BY [year], [month];


-- Conversion rate (Orders / Sessions) by month
SELECT
    YEAR(ws.created_at) AS [year],
    MONTH(ws.created_at) AS [month],
    COUNT(DISTINCT o.order_id) * 1.0 / NULLIF(COUNT(DISTINCT ws.website_session_id), 0) AS conversion_rate
FROM dbo.website_sessions ws
LEFT JOIN dbo.orders o
    ON o.website_session_id = ws.website_session_id
GROUP BY YEAR(ws.created_at), MONTH(ws.created_at)
ORDER BY [year], [month];


-- Which marketing channels are most successful (sessions, orders, revenue)
SELECT
    COALESCE(ws.utm_source, 'direct') AS channel,
    COUNT(DISTINCT ws.website_session_id) AS sessions,
    COUNT(DISTINCT o.order_id) AS orders,
    SUM(oi.price_usd) AS revenue
FROM dbo.website_sessions ws
LEFT JOIN dbo.orders o
    ON o.website_session_id = ws.website_session_id
LEFT JOIN dbo.order_items oi
    ON oi.order_id = o.order_id
GROUP BY COALESCE(ws.utm_source, 'direct')
ORDER BY revenue DESC;


-- Revenue per Order + Revenue per Session by month
SELECT
    YEAR(ws.created_at) AS [year],
    MONTH(ws.created_at) AS [month],
    SUM(oi.price_usd) * 1.0 / NULLIF(COUNT(DISTINCT o.order_id), 0) AS revenue_per_order,
    SUM(oi.price_usd) * 1.0 / NULLIF(COUNT(DISTINCT ws.website_session_id), 0) AS revenue_per_session
FROM dbo.website_sessions ws
LEFT JOIN dbo.orders o
    ON o.website_session_id = ws.website_session_id
LEFT JOIN dbo.order_items oi
    ON oi.order_id = o.order_id
GROUP BY YEAR(ws.created_at), MONTH(ws.created_at)
ORDER BY [year], [month];


-- Highest / Lowest sales products (by revenue)
-- Top 5 products
SELECT TOP 5
    p.product_name,
    SUM(oi.price_usd) AS revenue
FROM dbo.order_items oi
JOIN dbo.products p
    ON p.product_id = oi.product_id
GROUP BY p.product_name
ORDER BY revenue DESC;

-- Bottom 5 products
SELECT TOP 5
    p.product_name,
    SUM(oi.price_usd) AS revenue
FROM dbo.order_items oi
JOIN dbo.products p
    ON p.product_id = oi.product_id
GROUP BY p.product_name
ORDER BY revenue ASC;

-- Refunds vs Revenue by month 
SELECT
    YEAR(o.created_at) AS [year],
    MONTH(o.created_at) AS [month],
    SUM(oi.price_usd) AS revenue,
    SUM(COALESCE(r.refund_amount_usd, 0)) AS refunds
FROM dbo.orders o
LEFT JOIN dbo.order_items oi
    ON oi.order_id = o.order_id
LEFT JOIN dbo.order_item_refunds r
    ON r.order_item_id = oi.order_item_id
GROUP BY YEAR(o.created_at), MONTH(o.created_at)
ORDER BY [year], [month];