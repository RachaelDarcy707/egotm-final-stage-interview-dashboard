-- 01_base_dataset.sql
-- Database: OperationsDb
-- Purpose: joined dataset for analysis

USE OperationsDb;

SELECT
    -- sessions
    ws.website_session_id,
    CAST(ws.created_at AS date) AS session_date,
    ws.utm_source,
    ws.utm_campaign,
    ws.device_type,

    -- orders
    o.order_id,
    CAST(o.created_at AS date) AS order_date,

    -- products / revenue
    oi.order_item_id,
    oi.product_id,
    oi.price_usd,
    p.product_name,

    -- refunds
    r.refund_amount_usd,
    CAST(r.created_at AS date) AS refund_date

FROM dbo.website_sessions ws
LEFT JOIN dbo.orders o
    ON o.website_session_id = ws.website_session_id
LEFT JOIN dbo.order_items oi
    ON oi.order_id = o.order_id
LEFT JOIN dbo.products p
    ON p.product_id = oi.product_id
LEFT JOIN dbo.order_item_refunds r
    ON r.order_item_id = oi.order_item_id;